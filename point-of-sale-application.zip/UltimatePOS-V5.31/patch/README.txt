If you're using UltimatePOS V5.30, you can update to V5.31 by simply replacing the below 2 files:

resources/views/sale_pos/partials/pos_form_actions.blade.php
resources/views/sale_pos/partials/pos_form_totals.blade.php
